const spinCost = "0.001"; // ETH
const symbols = ["dog", "cat", "rabbit", "fox", "panda"];

let provider;
let signer;

document.getElementById("connectWallet").onclick = async () => {
  if (window.ethereum) {
    provider = new ethers.providers.Web3Provider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    signer = provider.getSigner();
    const address = await signer.getAddress();
    document.getElementById("walletAddress").textContent = address;
  } else {
    alert("MetaMask não instalada!");
  }
};

document.getElementById("spin").onclick = async () => {
  if (!signer) return alert("Conecte sua carteira!");

  const tx = {
    to: "0x0000000000000000000000000000000000000000", // Coloque o endereço que receberá o ETH
    value: ethers.utils.parseEther(spinCost),
  };

  try {
    await signer.sendTransaction(tx);

    // Slot aleatório
    const reel1 = symbols[Math.floor(Math.random() * symbols.length)];
    const reel2 = symbols[Math.floor(Math.random() * symbols.length)];
    const reel3 = symbols[Math.floor(Math.random() * symbols.length)];

    document.getElementById("reel1").src = "images/" + reel1 + ".png";
    document.getElementById("reel2").src = "images/" + reel2 + ".png";
    document.getElementById("reel3").src = "images/" + reel3 + ".png";

    let result = "Tente novamente!";
    if (reel1 === reel2 && reel2 === reel3) {
      result = "🎉 Você ganhou! Enviando recompensa...";
      // Aqui pode integrar com contrato para enviar token ERC-20
    }

    document.getElementById("result").textContent = result;
  } catch (err) {
    console.error(err);
    alert("Transação cancelada ou falhou.");
  }
};
